How to execute:

	go mod tidy

To start the server:
	go run . server

To start the client:
	go run . client